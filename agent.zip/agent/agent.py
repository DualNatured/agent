import argparse
import asyncio
import json
import os
import subprocess

import websockets


async def run_command(command: str, timeout: int):
    try:
        process = await asyncio.create_subprocess_shell(
            command,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
        )
        try:
            stdout, stderr = await asyncio.wait_for(process.communicate(), timeout)
        except asyncio.TimeoutError:
            process.kill()
            await process.wait()
            return 124, "", "command timed out"

        return (
            process.returncode,
            stdout.decode(errors="replace"),
            stderr.decode(errors="replace"),
        )
    except Exception as exc:
        return 1, "", str(exc)


async def connect_once(args):
    url = f"wss://{args.server}/ws"
    async with websockets.connect(
        url,
        ping_interval=20,
        ping_timeout=20,
        close_timeout=5,
        max_size=1024 * 1024,
    ) as ws:
        await ws.send(json.dumps({
            "role": "agent",
            "device": args.device,
            "token": args.token,
        }))

        reply = json.loads(await ws.recv())
        if not reply.get("ok"):
            raise RuntimeError(reply.get("error", "registration failed"))

        print(f"Connected to relay as {args.device}")

        async for raw in ws:
            msg = json.loads(raw)
            if msg.get("action") != "exec":
                continue

            command = str(msg.get("command", ""))
            timeout = max(1, min(int(msg.get("timeout", 60)), 300))
            code, stdout, stderr = await run_command(command, timeout)

            await ws.send(json.dumps({
                "type": "result",
                "request_id": msg.get("request_id"),
                "_controller_id": msg.get("_controller_id"),
                "exit_code": code,
                "stdout": stdout,
                "stderr": stderr,
            }))


async def main():
    parser = argparse.ArgumentParser(description="Remote CLI Windows agent")
    parser.add_argument("--server", required=True, help="Render host, e.g. my-app.onrender.com")
    parser.add_argument("--device", required=True, help="Unique name for this PC")
    parser.add_argument("--token", default=os.environ.get("RELAY_TOKEN"))
    args = parser.parse_args()

    if not args.token:
        raise SystemExit("Provide --token or RELAY_TOKEN.")

    while True:
        try:
            await connect_once(args)
        except Exception as exc:
            print(f"Disconnected: {exc}; retrying in 5 seconds...")
        await asyncio.sleep(5)


if __name__ == "__main__":
    asyncio.run(main())
