param(
  [Parameter(Mandatory=$true)][string]$Device
)

$taskName = "RemoteCliAgent-$Device"
Stop-ScheduledTask -TaskName $taskName -ErrorAction SilentlyContinue
Unregister-ScheduledTask -TaskName $taskName -Confirm:$false -ErrorAction SilentlyContinue
Write-Host "Removed $taskName"
