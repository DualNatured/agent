param(
  [Parameter(Mandatory=$true)][string]$PythonPath,
  [Parameter(Mandatory=$true)][string]$ProjectPath,
  [Parameter(Mandatory=$true)][string]$Server,
  [Parameter(Mandatory=$true)][string]$Device,
  [Parameter(Mandatory=$true)][string]$Token
)

$ErrorActionPreference = "Stop"
$taskName = "RemoteCliAgent-$Device"
$agent = Join-Path $ProjectPath "agent\agent.py"

if (!(Test-Path $PythonPath)) { throw "Python executable not found: $PythonPath" }
if (!(Test-Path $agent)) { throw "agent.py not found: $agent" }

$arguments = "`"$agent`" --server `"$Server`" --device `"$Device`" --token `"$Token`""

$action = New-ScheduledTaskAction `
    -Execute $PythonPath `
    -Argument $arguments `
    -WorkingDirectory $ProjectPath

$trigger = New-ScheduledTaskTrigger -AtStartup
$principal = New-ScheduledTaskPrincipal `
    -UserId "SYSTEM" `
    -LogonType ServiceAccount `
    -RunLevel Highest

$settings = New-ScheduledTaskSettingsSet `
    -RestartCount 999 `
    -RestartInterval (New-TimeSpan -Minutes 1) `
    -StartWhenAvailable

Register-ScheduledTask `
    -TaskName $taskName `
    -Action $action `
    -Trigger $trigger `
    -Principal $principal `
    -Settings $settings `
    -Force | Out-Null

Start-ScheduledTask -TaskName $taskName
Write-Host "Installed and started $taskName"
